
#include <sys/types.h>

void hostcompat_init(int argc, char **argv);

time_t __time(time_t *secs, unsigned long *nsecs);
